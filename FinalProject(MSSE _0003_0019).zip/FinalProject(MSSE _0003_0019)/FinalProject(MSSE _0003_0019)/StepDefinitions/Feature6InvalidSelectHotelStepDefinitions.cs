using FinalProject.Support.Select_Hotel;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Feature6InvalidSelectHotelStepDefinitions
    {
        InvalidSelectHotelClass invalidSelectHotelClass = new InvalidSelectHotelClass();
        [When(@"url open")]
        public void WhenUrlOpen()
        {
            invalidSelectHotelClass.BrowserIntialize();
            invalidSelectHotelClass.openURL();

        }

        [Given(@"Valid username")]
        public void GivenValidUsername()
        {
            invalidSelectHotelClass.login_username();
        }

        [Given(@"Valid password")]
        public void GivenValidPassword()
        {
            invalidSelectHotelClass.login_password();
        }

        [When(@"Click Login button")]
        public void WhenClickLoginButton()
        {
            invalidSelectHotelClass.login();
        }

        [Then(@"Validate login_assertion")]
        public void ThenValidateLogin_Assertion()
        {
            invalidSelectHotelClass.login_validate();
        }
        [Given(@"Location")]
        public void GivenLocation()
        {
                invalidSelectHotelClass.Location();
            }

        [Given(@"the Hotel")]
        public void GivenTheHotel()
        {
                invalidSelectHotelClass.Hotels();
            }

        [Given(@"the Room_type")]
        public void GivenTheRoom_Type()
        {
            invalidSelectHotelClass.RoomType();
        }

        [Given(@"the Number_rooms")]
        public void GivenTheNumber_Rooms()
        {
            invalidSelectHotelClass.RoomCount();
        }

        [Given(@"the Check_in date")]
        public void GivenTheCheck_InDate()
        {
            invalidSelectHotelClass.ChkInDate();
        }

        [Given(@"the check_out date")]
        public void GivenTheCheck_OutDate()
        {
            invalidSelectHotelClass.ChkOutDate();
        }

        [Given(@"the adults/room")]
        public void GivenTheAdultsRoom()
        {
            invalidSelectHotelClass.AdultCount();
        }

        [Given(@"the Children/room")]
        public void GivenTheChildrenRoom()
        {
            invalidSelectHotelClass.ChildCount();
        }

        [When(@"Clicked Search button")]
        public void WhenClickedSearchButton()
        {
            invalidSelectHotelClass.Search();
        }

        [Then(@"Validatsearch assertion")]
        public void ThenValidatsearchAssertion()
        {
            invalidSelectHotelClass.Search_Validate();
        }

        [When(@"Click on Continue Button without selecting radio button")]
        public void WhenClickOnContinueButtonWithoutSelectingRadioButton()
        {
            invalidSelectHotelClass.InvalidSelect();
        }

        [Then(@"validate error assertion")]
        public void ThenValidateErrorAssertion()
        {
            invalidSelectHotelClass.InvalidSelecttext();
        }

        [Then(@"Dispose_Driver")]
        public void ThenDispose_Driver()
        {
            invalidSelectHotelClass.DisposeDriver();
        }
    }
}
