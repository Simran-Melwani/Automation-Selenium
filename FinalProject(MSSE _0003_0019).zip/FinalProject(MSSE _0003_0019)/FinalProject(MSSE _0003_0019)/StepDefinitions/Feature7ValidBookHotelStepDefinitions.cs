using FinalProject.Support.Book_A_Hotel;
using FinalProject.Support.CancelBooking;
using FinalProject.Support.Logout;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Feature7ValidBookHotelStepDefinitions
    {
        ValidBookHotelClass validBookHotelClass = new ValidBookHotelClass();        
        
        [When(@"Url is open")]
        public void WhenUrlIsOpen()
        {
            validBookHotelClass.BrowserIntialize();
            validBookHotelClass.openURL();
        }

        [Given(@"Valid Username")]
        public void GivenValidUsername()
        {
            validBookHotelClass.login_username();
        }

        [Given(@"Valid Password")]
        public void GivenValidPassword()
        {
            validBookHotelClass.login_password();
        }

        [When(@"Click Login Button")]
        public void WhenClickLoginButton()
        {
            validBookHotelClass.login();
        }

        [Then(@"Validate Login_Assertion")]
        public void ThenValidateLogin_Assertion()
        {
            validBookHotelClass.login_validate();
        }

        [Given(@"A Location")]
        public void GivenALocation()
        {
            validBookHotelClass.Location();
        }

        [Given(@"Hotel")]
        public void GivenHotel()
        {
            validBookHotelClass.Hotels();
        }

        [Given(@"room_type")]
        public void GivenRoom_Type()
        {
            validBookHotelClass.RoomType();
        }

        [Given(@"number_rooms")]
        public void GivenNumber_Rooms()
        {
            validBookHotelClass.RoomCount();
        }

        [Given(@"check_in date")]
        public void GivenCheck_InDate()
        {
            validBookHotelClass.ChkInDate();
        }

        [Given(@"Check_out date")]
        public void GivenCheck_OutDate()
        {
            validBookHotelClass.ChkOutDate();
        }

        [Given(@"Adults per room")]
        public void GivenAdultsPerRoom()
        {
            validBookHotelClass.AdultCount();
        }

        [Given(@"children per room")]
        public void GivenChildrenPerRoom()
        {
            validBookHotelClass.ChildCount();
        }

        [When(@"clicked on Search button")]
        public void WhenClickedOnSearchButton()
        {
            validBookHotelClass.Search();
        }

        [Then(@"Validate search assertion")]
        public void ThenValidateSearchAssertion()
        {
            validBookHotelClass.Search_Validate();
        }

        [When(@"Click on Continue_Button with select the hotel")]
        public void WhenClickOnContinue_ButtonWithSelectTheHotel()
        {
            validBookHotelClass.ValidSelect();
        }

        [Then(@"validate book hotel page assertion")]
        public void ThenValidateBookHotelPageAssertion()
        {
            validBookHotelClass.Selecthotel_Validate();
        }

        [Given(@"the FirstName")]
        public void GivenTheFirstName()
        {
            validBookHotelClass.BH_FirstName();
        }

        [Given(@"the Last Name")]
        public void GivenTheLastName()
        {
            validBookHotelClass.BH_LastName();
        }

        [Given(@"the Billing address")]
        public void GivenTheBillingAddress()
        {
            validBookHotelClass.Billing_Address();
        }

        [Given(@"credit card no")]
        public void GivenCreditCardNo()
        {
            validBookHotelClass.Credit_Card_No();
        }

        [Given(@"credit card type")]
        public void GivenCreditCardType()
        {
            validBookHotelClass.Credit_Card_Type();
        }

        [Given(@"expiry date in moths")]
        public void GivenExpiryDateInMoths()
        {
            validBookHotelClass.Expiry_Month();
        }

        [Given(@"expiry date in years")]
        public void GivenExpiryDateInYears()
        {
            validBookHotelClass.Expiry_Year();
        }

        [Given(@"the CVV no")]
        public void GivenTheCVVNo()
        {
            validBookHotelClass.CVV_Number();
        }

        [When(@"Click on Book_now button")]
        public void WhenClickOnBook_NowButton()
        {
            validBookHotelClass.Book_Now();
        }

        [Then(@"Validate that my_itinerary buttton Appear")]
        public void ThenValidateThatMy_ItineraryButttonAppear()
        {
            validBookHotelClass.My_Itinerary_Validate();
        }

        [Then(@"Dispose a Driver")]
        public void ThenDisposeADriver()
        {
            validBookHotelClass.DisposeDriver();
        }
    }
}
