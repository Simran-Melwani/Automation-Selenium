using FinalProject.Support.Book_A_Hotel;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Feature8InvalidBookHotelStepDefinitions
    {

        InvalidBookHotelClass invalidBookHotelClass = new InvalidBookHotelClass();

        [Given(@"Open the url")]
        public void GivenOpenTheUrl()
        {
            invalidBookHotelClass.BrowserIntialize();
            invalidBookHotelClass.openURL();
        }

        [Given(@"Enter valid username")]
        public void GivenEnterValidUsername()
        {
            invalidBookHotelClass.login_username();
        }

        [Given(@"Enter valid password")]
        public void GivenEnterValidPassword()
        {
            invalidBookHotelClass.login_password();
        }

        [When(@"click on login button")]
        public void WhenClickOnLoginButton()
        {
            invalidBookHotelClass.login();
        }

        [Then(@"Validate login assertion")]
        public void ThenValidateLoginAssertion()
        {
            invalidBookHotelClass.login_validate();
        }

        [Given(@"select location")]
        public void GivenSelectLocation()
        {
            invalidBookHotelClass.Location();
        }

        [Given(@"select hotel")]
        public void GivenSelectHotel()
        {
            invalidBookHotelClass.Hotels();
        }

        [Given(@"select room type")]
        public void GivenSelectRoomType()
        {
            invalidBookHotelClass.RoomType();
        }

        [Given(@"number of Rooms")]
        public void GivenNumberOfRooms()
        {
            invalidBookHotelClass.RoomCount();
        }

        [Given(@"CheckIn date")]
        public void GivenCheckInDate()
        {
            invalidBookHotelClass.ChkInDate();
        }

        [Given(@"CheckOut date")]
        public void GivenCheckOutDate()
        {
            invalidBookHotelClass.ChkOutDate();
        }

        [Given(@"adults per room")]
        public void GivenAdultsPerRoom()
        {
            invalidBookHotelClass.AdultCount();
        }

        [Given(@"Children per room")]
        public void GivenChildrenPerRoom()
        {
            invalidBookHotelClass.ChildCount();
        }

        [When(@"Click Search Button")]
        public void WhenClickSearchButton()
        {
            invalidBookHotelClass.Search();
        }

        [Then(@"validate search assertion")]
        public void ThenValidateSearchAssertion()
        {
            invalidBookHotelClass.Search_Validate();
        }

        [When(@"click continue button")]
        public void WhenClickContinueButton()
        {
            invalidBookHotelClass.ValidSelect();
        }

        [Then(@"validate Book hotel assertion")]
        public void ThenValidateBookHotelAssertion()
        {
            invalidBookHotelClass.Selecthotel_Validate();
        }

        [Given(@"enter first name")]
        public void GivenEnterFirstName()
        {
            invalidBookHotelClass.BH_FirstName();
        }

        [Given(@"enter last name")]
        public void GivenEnterLastName()
        {
            invalidBookHotelClass.BH_LastName();
        }

        [Given(@"enter billing address")]
        public void GivenEnterBillingAddress()
        {
            invalidBookHotelClass.Billing_Address();
        }

        [Given(@"enter credit card number")]
        public void GivenEnterCreditCardNumber()
        {
            invalidBookHotelClass.Credit_Card_No();
        }

        [Given(@"select credit card type")]
        public void GivenSelectCreditCardType()
        {
            invalidBookHotelClass.Credit_Card_Type();
        }

        [Given(@"select expiry month")]
        public void GivenSelectExpiryMonth()
        {
            invalidBookHotelClass.Expiry_Month();
        }

        [Given(@"select expiry year")]
        public void GivenSelectExpiryYear()
        {
            invalidBookHotelClass.Expiry_Year();
        }

        [When(@"click BookNow button")]
        public void WhenClickBookNowButton()
        {
            invalidBookHotelClass.Book_Now();
        }

        [Then(@"validate book error assertion")]
        public void ThenValidateBookErrorAssertion()
        {
            invalidBookHotelClass.InvalidBookHotel();
        }

        [Then(@"dispose the driver")]
        public void ThenDisposeTheDriver()
        {
            invalidBookHotelClass.DisposeDriver();
        }
    }
}
