using FinalProject.Support.CancelBooking;
using FinalProject.Support.My_Itinerary;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Features10ValidBookingCancelStepDefinitions
    {
        CancelBookingClass cancelBookingClass = new CancelBookingClass();
        InvalidSearchBookedItineraryClass invalidSearchBkdItineraryClass = new InvalidSearchBookedItineraryClass();

        [Given(@"Open the Url")]
        public void GivenOpenTheUrl()
        {
            cancelBookingClass.BrowserIntialize();
            cancelBookingClass.openURL();
        }

        [Given(@"enter Valid username")]
        public void GivenEnterValidUsername()
        {
            cancelBookingClass.login_username();
        }

        [Given(@"enter Valid password")]
        public void GivenEnterValidPassword()
        {
            cancelBookingClass.login_password();
        }

        [When(@"click on Login button")]
        public void WhenClickOnLoginButton()
        {
            cancelBookingClass.login();
        }

        [Then(@"Validate Login assertion")]
        public void ThenValidateLoginAssertion()
        {
            cancelBookingClass.login_validate();
        }

        [Given(@"Select location")]
        public void GivenSelectLocation()
        {
            cancelBookingClass.Location();
        }

        [Given(@"Select hotel")]
        public void GivenSelectHotel()
        {
            cancelBookingClass.Hotels();
        }

        [Given(@"Select Room type")]
        public void GivenSelectRoomType()
        {
            cancelBookingClass.RoomType();
        }

        [Given(@"Number of Rooms")]
        public void GivenNumberOfRooms()
        {
            cancelBookingClass.RoomCount();
        }

        [Given(@"CheckIn Date")]
        public void GivenCheckInDate()
        {
            cancelBookingClass.ChkInDate();
        }

        [Given(@"CheckOut Date")]
        public void GivenCheckOutDate()
        {
            cancelBookingClass.ChkOutDate();
        }

        [Given(@"adults per Room")]
        public void GivenAdultsPerRoom()
        {
            cancelBookingClass.AdultCount();
        }

        [Given(@"children per Room")]
        public void GivenChildrenPerRoom()
        {
            cancelBookingClass.ChildCount();
        }

        [When(@"click search button")]
        public void WhenClickSearchButton()
        {
            cancelBookingClass.Search();
        }

        [Then(@"validate search Assertion")]
        public void ThenValidateSearchAssertion()
        {
            cancelBookingClass.Search_Validate();
        }

        [Then(@"click Continue button")]
        public void ThenClickContinueButton()
        {
            cancelBookingClass.ValidSelect();
        }

        [Then(@"validate bookHotel page assertion")]
        public void ThenValidateBookHotelPageAssertion()
        {
            cancelBookingClass.Selecthotel_Validate();
        }

        [Given(@"enter First name")]
        public void GivenEnterFirstName()
        {
            cancelBookingClass.BH_FirstName();
        }

        [Given(@"enter Last name")]
        public void GivenEnterLastName()
        {
            cancelBookingClass.BH_LastName();
        }

        [Given(@"enter Billing Address")]
        public void GivenEnterBillingAddress()
        {
            cancelBookingClass.Billing_Address();
        }

        [Given(@"enter Credit Card number")]
        public void GivenEnterCreditCardNumber()
        {
            cancelBookingClass.Credit_Card_No();
        }

        [Given(@"select Credit Card type")]
        public void GivenSelectCreditCardType()
        {
            cancelBookingClass.Credit_Card_Type();
        }

        [Given(@"select expiry Month")]
        public void GivenSelectExpiryMonth()
        {
            cancelBookingClass.Expiry_Month();
        }

        [Given(@"select expiry Year")]
        public void GivenSelectExpiryYear()
        {
            cancelBookingClass.Expiry_Year();
        }

        [Given(@"enter CVV number")]
        public void GivenEnterCVVNumber()
        {
            cancelBookingClass.CVV_Number();
        }

        [When(@"click on BookNow button")]
        public void WhenClickOnBookNowButton()
        {
            cancelBookingClass.Book_Now();
        }

        [Then(@"validate my itinerary button appears")]
        public void ThenValidateMyItineraryButtonAppears()
        {
            cancelBookingClass.My_Itinerary_Validate();
        }

        [Then(@"click on My Itinerary button")]
        public void ThenClickOnMyItineraryButton()
        {
            cancelBookingClass.Myitinerary();
        }

        [Then(@"validate Booked itinerary assertion")]
        public void ThenValidateBookedItineraryAssertion()
        {
            invalidSearchBkdItineraryClass.BookedItineraryAssertion();
        }

        [Given(@"click on checkbox for cancel booking")]
        public void GivenClickOnCheckboxForCancelBooking()
        {
            cancelBookingClass.CancelBookingCheckbox();
        }

        [Given(@"click on cancel selected button")]
        public void GivenClickOnCancelSelectedButton()
        {
            cancelBookingClass.CancelSelected();
        }

        [When(@"accept pop up")]
        public void WhenAcceptPopUp()
        {
            cancelBookingClass.PopUp();
        }

        [Then(@"validate booking cancel assertion")]
        public void ThenValidateBookingCancelAssertion()
        {
            cancelBookingClass.BookingCancelValidationText();
        }

        [Then(@"Dispose the driver")]
        public void ThenDisposeTheDriver()
        {
            cancelBookingClass.DisposeDriver();
        }
    }
}
