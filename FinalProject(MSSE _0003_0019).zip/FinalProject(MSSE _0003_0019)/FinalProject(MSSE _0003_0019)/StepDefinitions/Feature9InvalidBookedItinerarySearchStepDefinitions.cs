using FinalProject.Support.My_Itinerary;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Feature9InvalidBookedItinerarySearchStepDefinitions
    {
        InvalidSearchBookedItineraryClass invalidSearchBkdItineraryClass = new InvalidSearchBookedItineraryClass();

        [Given(@"open url")]
        public void GivenOpenUrl()
        {
            invalidSearchBkdItineraryClass.BrowserIntialize();
            invalidSearchBkdItineraryClass.openURL();
        }

        [Given(@"enter the Valid username")]
        public void GivenEnterTheValidUsername()
        {
            invalidSearchBkdItineraryClass.login_username();
        }

        [Given(@"enter the Valid password")]
        public void GivenEnterTheValidPassword()
        {
            invalidSearchBkdItineraryClass.login_password();
        }

        [When(@"Click on Login Button")]
        public void WhenClickOnLoginButton()
        {
            invalidSearchBkdItineraryClass.login();
        }

        [Then(@"Validate Login Assertion")]
        public void ThenValidateLoginAssertion()
        {
            invalidSearchBkdItineraryClass.login_validate();
        }

        [When(@"click on booked itinerary")]
        public void WhenClickOnBookedItinerary()
        {
            invalidSearchBkdItineraryClass.BookedItinerary();
        }

        [Then(@"validate booked itinerary assertion")]
        public void ThenValidateBookedItineraryAssertion()
        {
            invalidSearchBkdItineraryClass.BookedItineraryAssertion();
        }

        [Given(@"enter search order Id")]
        public void GivenEnterSearchOrderId()
        {
            invalidSearchBkdItineraryClass.SearchOrderID();
        }

        [When(@"click on Go button")]
        public void WhenClickOnGoButton()
        {
            invalidSearchBkdItineraryClass.Go_Button();
        }

        [Then(@"booked_itinerary_search error assertion")]
        public void ThenBooked_Itinerary_SearchErrorAssertion()
        {
            invalidSearchBkdItineraryClass.BkdSearchError();
        }

        [Then(@"Dispose driver")]
        public void ThenDisposeDriver()
        {
            invalidSearchBkdItineraryClass.DisposeDriver();
        }
    }
}
