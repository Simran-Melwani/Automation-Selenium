using FinalProject.Support.Search_Hotel;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Feature4InvalidSearchHotelStepDefinitions
    {
        InvalidSearchHotelClass invalidSearchHotelClass = new InvalidSearchHotelClass();
        [When(@"the url_open")]
        public void WhenTheUrl_Open()
        {
            invalidSearchHotelClass.BrowserIntialize();
            invalidSearchHotelClass.openURL();
        }

        [Given(@"enter the valid username")]
        public void GivenEnterTheValidUsername()
        {
            invalidSearchHotelClass.login_username();
        }

        [Given(@"enter the valid password")]
        public void GivenEnterTheValidPassword()
        {
            invalidSearchHotelClass.login_password();
        }

        [When(@"click the login button")]
        public void WhenClickTheLoginButton()
        {
            invalidSearchHotelClass.login();
        }

        [Then(@"validate the loggedin text")]
        public void ThenValidateTheLoggedinText()
        {
            invalidSearchHotelClass.login_validate();
        }

        [Given(@"the location")]
        public void GivenTheLocation()
        {
            invalidSearchHotelClass.Location();
        }

        [Given(@"hotel")]
        public void GivenHotel()
        {
            invalidSearchHotelClass.Hotels();
        }

        [Given(@"room type")]
        public void GivenRoomType()
        {
            invalidSearchHotelClass.RoomType();
        }

        [Given(@"number of rooms")]
        public void GivenNumberOfRooms()
        {
            invalidSearchHotelClass.RoomCount();
        }

        [Given(@"checkin date")]
        public void GivenCheckinDate()
        {
            invalidSearchHotelClass.ChkInDate();
        }

        [Given(@"invalid checkout date")]
        public void GivenInvalidCheckoutDate()
        {
            invalidSearchHotelClass.InvalidChkOutDate();
        }

        [When(@"click Search button")]
        public void WhenClickSearchButton()
        {
            invalidSearchHotelClass.Search();
        }

        [Then(@"validate the invlid date assertion")]
        public void ThenValidateTheInvlidDateAssertion()
        {
            invalidSearchHotelClass.InvalidChkInText();
        }

        [Then(@"Close Driver")]
        public void ThenCloseDriver()
        {
            invalidSearchHotelClass.DisposeDriver();
        }
    }
}
