using FinalProject.Support.Book_A_Hotel;
using FinalProject.Support.Select_Hotel;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Feature5SelectHotelStepDefinitions
    {
        ValidSelectHotelClass validSelectHotelClass = new ValidSelectHotelClass();        

        [When(@"url is open")]
        public void WhenUrlIsOpen()
        {
            validSelectHotelClass.BrowserIntialize();
            validSelectHotelClass.openURL();
        }

        [Given(@"valid username")]
        public void GivenValidUsername()
        {
            validSelectHotelClass.login_username();
        }

        [Given(@"valid password")]
        public void GivenValidPassword()
        {
            validSelectHotelClass.login_password();
        }

        [When(@"Click login button")]
        public void WhenClickLoginButton()
        {
            validSelectHotelClass.login();
        }

        [Then(@"validate login_assertion")]
        public void ThenValidateLogin_Assertion()
        {
            validSelectHotelClass.login_validate();
        }

        [Given(@"the Location")]
        public void GivenTheLocation()
        {
            validSelectHotelClass.Location();
        }

        [Given(@"the hotel")]
        public void GivenTheHotel()
        {
            validSelectHotelClass.Hotels();
        }

        [Given(@"the room_type")]
        public void GivenTheRoom_Type()
        {
            validSelectHotelClass.RoomType();
        }

        [Given(@"the number_rooms")]
        public void GivenTheNumber_Rooms()
        {
            validSelectHotelClass.RoomCount();
        }

        [Given(@"the check_in date")]
        public void GivenTheCheck_InDate()
        {
            validSelectHotelClass.ChkInDate();
        }

        [Given(@"the Check_out date")]
        public void GivenTheCheck_OutDate()
        {
            validSelectHotelClass.ChkOutDate();
        }

        [Given(@"the Adults/room")]
        public void GivenTheAdultsRoom()
        {
            validSelectHotelClass.AdultCount();
        }

        [Given(@"the children/room")]
        public void GivenTheChildrenRoom()
        {
            validSelectHotelClass.ChildCount();
        }

        [When(@"clicked Search button")]
        public void WhenClickedSearchButton()
        {
            validSelectHotelClass.Search();
        }

        [Then(@"validatsearch assertion")]
        public void ThenValidatsearchAssertion()
        {
            validSelectHotelClass.Search_Validate();
        }

        [When(@"Click on Continue Button")]
        public void WhenClickOnContinueButton()
        {
            validSelectHotelClass.ValidSelect();
        }

        [Then(@"validate book hotel assertion")]
        public void ThenValidateBookHotelAssertion()
        {
            validSelectHotelClass.Selecthotel_Validate();
        }

        [Then(@"Dispose Driver")]
        public void ThenDisposeDriver()
        {            
            validSelectHotelClass.DisposeDriver();
        }
    }
}
