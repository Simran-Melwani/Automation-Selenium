using FinalProject.Support.Search_Hotel;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Feature3ValidSearchHotelStepDefinitions
    {
        SearchHotelClass searchHotelClass = new SearchHotelClass();
        [When(@"the url is open")]
        public void WhenTheUrlIsOpen()
        {
            searchHotelClass.BrowserIntialize();
            searchHotelClass.openURL();
        }

        [Given(@"the valid username")]
        public void GivenTheValidUsername()
        {
            searchHotelClass.login_username();
        }

        [Given(@"the valid password")]
        public void GivenTheValidPassword()
        {
            searchHotelClass.login_password();
        }

        [When(@"Click on the login button")]
        public void WhenClickOnTheLoginButton()
        {
            searchHotelClass.login();
        }

        [Then(@"validate the login_assertion")]
        public void ThenValidateTheLogin_Assertion()
        {
            searchHotelClass.login_validate();
        }

        [Given(@"the Location Input")]
        public void GivenTheLocationInput()
        {
            searchHotelClass.Location();
        }

        [Given(@"the hotel Input")]
        public void GivenTheHotelInput()
        {
            searchHotelClass.Hotels();
        }

        [Given(@"the room type")]
        public void GivenTheRoomType()
        {
            searchHotelClass.RoomType();
        }

        [Given(@"the number of rooms")]
        public void GivenTheNumberOfRooms()
        {
            searchHotelClass.RoomCount();
        }

        [Given(@"the the check in date")]
        public void GivenTheTheCheckInDate()
        {
            searchHotelClass.ChkInDate();
        }

        [Given(@"the Check out date")]
        public void GivenTheCheckOutDate()
        {
            searchHotelClass.ChkOutDate();
        }

        [Given(@"the Adults per room")]
        public void GivenTheAdultsPerRoom()
        {
            searchHotelClass.AdultCount();
        }

        [Given(@"the children per room")]
        public void GivenTheChildrenPerRoom()
        {
            searchHotelClass.ChildCount();
        }

        [When(@"click on Search button")]
        public void WhenClickOnSearchButton()
        {
            searchHotelClass.Search();
        }

        [Then(@"validate the search assertion")]
        public void ThenValidateTheSearchAssertion()
        {
            searchHotelClass.Search_Validate();
        }

        [Then(@"Dispose your Driver")]
        public void ThenDisposeYourDriver()
        {
            searchHotelClass.DisposeDriver();
        }
    }
}
