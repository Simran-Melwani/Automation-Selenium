using FinalProject.Support.Login;
using FinalProject.Support.My_Itinerary;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Feature1LoginValidStepDefinitions
    {
        ValidLogin validLogin = new ValidLogin();

        [When(@"the url open")]
        public void WhenTheUrlOpen()
        {
            validLogin.BrowserIntialize();
            validLogin.openURL();
        }

        [Given(@"the username")]
        public void GivenTheUsername()
        {
            validLogin.login_username();
        }

        [Given(@"the password")]
        public void GivenThePassword()
        {
            validLogin.login_password();
        }

        [When(@"Click on login button")]
        public void WhenClickOnLoginButton()
        { 
            validLogin.login();
        }

        [Then(@"validate the login assertion")]
        public void ThenValidateTheLoginAssertion()
        {
            validLogin.login_validate();
        }

        [Then(@"Dispose the Driver")]
        public void ThenDisposeTheDriver()
        {
            validLogin.DisposeDriver();
        }
    }
}
