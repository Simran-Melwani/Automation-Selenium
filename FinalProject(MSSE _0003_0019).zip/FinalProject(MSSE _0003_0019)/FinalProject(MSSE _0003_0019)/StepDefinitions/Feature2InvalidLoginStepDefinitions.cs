using FinalProject.Support.Login;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Feature2InvalidLoginStepDefinitions
    {
        InvalidLogin invalidlogin = new InvalidLogin();

        [Given(@"open the url")]
        public void GivenOpenTheUrl()
        {
            invalidlogin.BrowserIntialize();
            invalidlogin.openURL();
        }

        [When(@"enter valid username")]
        public void WhenEnterValidUsername()
        {            
            invalidlogin.login_username();
        }

        [When(@"enter invalid password")]
        public void WhenEnterInvalidPassword()
        {
            invalidlogin.InvalidValidPassword();
        }

        [Then(@"click login button")]
        public void ThenClickLoginButton()
        {            
            invalidlogin.login();
        }

        [Then(@"validate invalid text")]
        public void ThenValidateInvalidText()
        {
            invalidlogin.InvalidLoginText();
        }

        [Then(@"dispose driver")]
        public void ThenDisposeDriver()
        {
            invalidlogin.DisposeDriver();
        }
    }
}
