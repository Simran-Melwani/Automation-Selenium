using FinalProject.Support.Logout;
using FinalProject.Support.My_Itinerary;
using System;
using TechTalk.SpecFlow;

namespace FinalProject.StepDefinitions
{
    [Binding]
    public class Features11ValidLogoutStepDefinitions
    {

        LogoutClass logoutClass = new LogoutClass();
        InvalidSearchBookedItineraryClass invalidSearchBkdItineraryClass = new InvalidSearchBookedItineraryClass();

        [Given(@"Open Url")]
        public void GivenOpenUrl()
        {
            logoutClass.BrowserIntialize();
            logoutClass.openURL();
        }

        [Given(@"enter valid Username")]
        public void GivenEnterValidUsername()
        {
            logoutClass.login_username();
        }

        [Given(@"enter valid Password")]
        public void GivenEnterValidPassword()
        {
            logoutClass.login_password();
        }

        [When(@"click on Login Button")]
        public void WhenClickOnLoginButton()
        {
            logoutClass.login();
        }

        [Then(@"validate Login Assertion")]
        public void ThenValidateLoginAssertion()
        {
            logoutClass.login_validate();
        }

        [Given(@"select the location")]
        public void GivenSelectTheLocation()
        {
            logoutClass.Location();
        }

        [Given(@"select the Hotel")]
        public void GivenSelectTheHotel()
        {
            logoutClass.Hotels();
        }

        [Given(@"select Room type")]
        public void GivenSelectRoomType()
        {
            logoutClass.RoomType();
        }

        [Given(@"Number of rooms")]
        public void GivenNumberOfRooms()
        {
            logoutClass.RoomCount();
        }

        [Given(@"checkIn date")]
        public void GivenCheckInDate()
        {
            logoutClass.ChkInDate();
        }

        [Given(@"checkOut date")]
        public void GivenCheckOutDate()
        {
            logoutClass.ChkOutDate();
        }

        [Given(@"Adults per Room")]
        public void GivenAdultsPerRoom()
        {
            logoutClass.AdultCount();
        }

        [Given(@"Children per Room")]
        public void GivenChildrenPerRoom()
        {
            logoutClass.ChildCount();
        }

        [When(@"Click search button")]
        public void WhenClickSearchButton()
        {
            logoutClass.Search();
        }

        [Then(@"validate Search assertion")]
        public void ThenValidateSearchAssertion()
        {
            logoutClass.Search_Validate();
        }

        [Then(@"click continue Button")]
        public void ThenClickContinueButton()
        {
            logoutClass.ValidSelect();
        }

        [Then(@"Validate book hotel assertion")]
        public void ThenValidateBookHotelAssertion()
        {
            logoutClass.Selecthotel_Validate();
        }

        [Given(@"enter First Name")]
        public void GivenEnterFirstName()
        {
            logoutClass.BH_FirstName();
        }

        [Given(@"enter Last Name")]
        public void GivenEnterLastName()
        {
            logoutClass.BH_LastName();
        }

        [Given(@"enter Billing address")]
        public void GivenEnterBillingAddress()
        {
            logoutClass.Billing_Address();
        }

        [Given(@"enter Credit Card Number")]
        public void GivenEnterCreditCardNumber()
        {
            logoutClass.Credit_Card_No();
        }

        [Given(@"select Credit Card Type")]
        public void GivenSelectCreditCardType()
        {
            logoutClass.Credit_Card_Type();
        }

        [Given(@"select Expiry Month")]
        public void GivenSelectExpiryMonth()
        {
            logoutClass.Expiry_Month();
        }

        [Given(@"select Expiry Year")]
        public void GivenSelectExpiryYear()
        {
            logoutClass.Expiry_Year();
        }

        [Given(@"enter CVV no")]
        public void GivenEnterCVVNo()
        {
            logoutClass.CVV_Number();
        }

        [When(@"Click BookNow button")]
        public void WhenClickBookNowButton()
        {
            logoutClass.Book_Now();
        }

        [Then(@"validate My Itinerary button appears")]
        public void ThenValidateMyItineraryButtonAppears()
        {
            logoutClass.My_Itinerary_Validate();
        }

        [Then(@"click My Itinerary button")]
        public void ThenClickMyItineraryButton()
        {
            logoutClass.Myitinerary();
        }

        [Then(@"validate Booked Itinerary assertion")]
        public void ThenValidateBookedItineraryAssertion()
        {
            invalidSearchBkdItineraryClass.BookedItineraryAssertion();
        }

        [Given(@"click on CheckBox for cancel booking")]
        public void GivenClickOnCheckBoxForCancelBooking()
        {
            logoutClass.CancelBookingCheckbox();
        }

        [Given(@"click on Cancel Selected button")]
        public void GivenClickOnCancelSelectedButton()
        {
            logoutClass.CancelSelected();
        }

        [When(@"Accept pop up")]
        public void WhenAcceptPopUp()
        {
            logoutClass.PopUp();
        }

        [Then(@"validate Booking Cancel Assertion")]
        public void ThenValidateBookingCancelAssertion()
        {
            logoutClass.BookingCancelValidationText();
        }

        [Given(@"click on logout button")]
        public void GivenClickOnLogoutButton()
        {
            logoutClass.Logout();
        }

        [Given(@"validate logout assertion")]
        public void GivenValidateLogoutAssertion()
        {
            logoutClass.LogoutValidationText();
        }

        [When(@"click on login again")]
        public void WhenClickOnLoginAgain()
        {
            logoutClass.LoginAgain();
        }

        [Then(@"validate login again assertion")]
        public void ThenValidateLoginAgainAssertion()
        {
            logoutClass.LoginAgainValidationText();
        }

        [Then(@"dispose Driver")]
        public void ThenDisposeDriver()
        {
            logoutClass.DisposeDriver();
        }
    }
}
