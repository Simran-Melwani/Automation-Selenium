﻿using FinalProject.Support.Data;
using FinalProject.Support.Login;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Support.My_Itinerary
{
    public class InvalidSearchBookedItineraryClass: ValidLogin
    {
        string bkd_itinerary_text = DataClass.booked_itinerary_text;
        string search_orderId = DataClass.search_orderId;
        string bkd_searcherror_text = DataClass.booked_searcherror_text;

        
        public void BookedItinerary()
        {
            chromeDriver.FindElement(By.XPath(LocatorClass.bkd_itinerary_btn)).Click();
        }

        public void BookedItineraryAssertion()
        {
            string booked_itinerary_txt = chromeDriver.FindElement(By.ClassName(LocatorClass.bkd_itinerary_txt)).Text;
            Assert.AreEqual(booked_itinerary_txt, bkd_itinerary_text);
        }

        public void SearchOrderID()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.Search_order_Id)).SendKeys(search_orderId);            
        }

        public void Go_Button()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.Go_btn)).Click();
        }

        public void BkdSearchError()
        {
            string booked_searcherror_txt = chromeDriver.FindElement(By.Id(LocatorClass.bkd_searcherror_txt)).Text;
            Assert.AreEqual(booked_searcherror_txt, bkd_searcherror_text);            
        }       
    }
}
