﻿using FinalProject.Support.Data;
using FinalProject.Support.Search_Hotel;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Support.Select_Hotel
{
    public class InvalidSelectHotelClass : SearchHotelClass
    {
        string select_error = DataClass.select_hotel_error;
        public void InvalidSelect()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.continue_btn)).Click();
        }
        public void InvalidSelecttext() {
            string error_text = chromeDriver.FindElement(By.ClassName(LocatorClass.sel_htlerror)).Text;
            Assert.AreEqual(error_text, select_error);

        }
    }
}
