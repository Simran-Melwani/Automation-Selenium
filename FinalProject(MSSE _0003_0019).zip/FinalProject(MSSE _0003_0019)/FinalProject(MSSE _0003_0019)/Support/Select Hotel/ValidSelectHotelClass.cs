﻿using FinalProject.Support.Data;
using FinalProject.Support.Search_Hotel;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Support.Select_Hotel
{
    public class ValidSelectHotelClass:SearchHotelClass
    {
        string bookhotelvalidText = DataClass.bookhotelvalidText;
        public void ValidSelect()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.sel_ht_radio)).Click();
            chromeDriver.FindElement(By.Id(LocatorClass.continue_btn)).Click();
        }
        public void Selecthotel_Validate()
        {
            string bookhotel_validate = chromeDriver.FindElement(By.XPath(LocatorClass.bookhotel_validate)).Text;
            Assert.AreEqual(bookhotel_validate, bookhotelvalidText);

        }
    }
}
