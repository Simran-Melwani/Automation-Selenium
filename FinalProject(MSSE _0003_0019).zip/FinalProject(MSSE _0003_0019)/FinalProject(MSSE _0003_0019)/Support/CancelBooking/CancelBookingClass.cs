﻿using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FinalProject.Support.Book_A_Hotel;
using OpenQA.Selenium.Support.UI;
using FinalProject.Support.Data;
using NUnit.Framework;

namespace FinalProject.Support.CancelBooking
{
    public class CancelBookingClass : ValidBookHotelClass
    {
        string bkngcncl_text = DataClass.booking_cancel_text;
        public void Myitinerary()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.my_itinerary_btn)).Click();
        }

        public void CancelBookingCheckbox()
        {
            chromeDriver.FindElement(By.CssSelector(LocatorClass.cancel_CheckBox)).Click();
        }
      
        public void CancelSelected()
        {
            chromeDriver.FindElement(By.ClassName(LocatorClass.Cancel_selected_btn)).Click();
        }

        public void PopUp()
        {
            var alert = chromeDriver.SwitchTo().Alert();
            alert.Accept();
        }
                
        public void BookingCancelValidationText()
        {
            string bkngcncl_txt = chromeDriver.FindElement(By.Id(LocatorClass.BookingCancelText)).Text;
            Assert.AreEqual(bkngcncl_txt, bkngcncl_text);
        }         
    }
}
