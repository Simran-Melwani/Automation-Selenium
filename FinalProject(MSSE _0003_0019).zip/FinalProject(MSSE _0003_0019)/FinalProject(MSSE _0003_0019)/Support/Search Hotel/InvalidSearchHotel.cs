﻿using FinalProject.Support.Data;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Support.Search_Hotel
{
    public class InvalidSearchHotelClass:SearchHotelClass
    {
        string invalid_chkoutdate = DataClass.invalidchkout_date;
        string invalid_chkouttext = DataClass.invalidchkouttext;
        public void InvalidChkOutDate()
        {
            var InvalidCheckoundate = chromeDriver.FindElement(By.XPath(LocatorClass.chkout_date));
            InvalidCheckoundate.Clear();
            InvalidCheckoundate.SendKeys(invalid_chkoutdate);
        }
        public void InvalidChkInText()
        {
            string invalidsearch_text = chromeDriver.FindElement(By.XPath(LocatorClass.search_invalid)).Text;
            Assert.AreEqual(invalid_chkouttext, invalidsearch_text);
        }
    }
}
