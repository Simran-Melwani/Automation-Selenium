﻿using FinalProject.Support.Data;
using FinalProject.Support.Login;
using NUnit.Framework;
using NUnit.Framework.Internal;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace FinalProject.Support.Search_Hotel
{
    public class SearchHotelClass:ValidLogin
    {
        string loc_Text = DataClass.loc_Text;
        string hotels = DataClass.hotel_value;
        string room_type = DataClass.room_type;
        string room_count = DataClass.room_count;
        string checkin_date = DataClass.chkin_date;
        string checkout_date = DataClass.chkout_date;
        string adult_count = DataClass.adult_count;
        string child_count = DataClass.child_count;
        string search_Validate = DataClass.searchvalidText;


        public void Location()
        {
            var location = chromeDriver.FindElement(By.Id(LocatorClass.Location));
            var loc_dropdown = new SelectElement(location);
            loc_dropdown.SelectByText(loc_Text);
            
        }
        public void Hotels()
        {
            var Hotels = chromeDriver.FindElement(By.Id(LocatorClass.Hotels));
            var hotels_dropdown = new SelectElement(Hotels);
            hotels_dropdown.SelectByValue(hotels);
        }
        public void RoomType()
        {
            var room_tp= chromeDriver.FindElement(By.Id(LocatorClass.Rm_Type));
            var room_tp_dropdown = new SelectElement(room_tp);
            room_tp_dropdown.SelectByText(room_type);
        }
        public void RoomCount()
        {
            var room_no = chromeDriver.FindElement(By.Id(LocatorClass.Rm_No));
            var room_no_dropdown = new SelectElement(room_no);
            room_no_dropdown.SelectByValue(room_count);
        }
        public void ChkInDate()
        {
            var Checkindate = chromeDriver.FindElement(By.XPath(LocatorClass.chkin_date));
            Checkindate.Clear();
            Checkindate.SendKeys(checkin_date);
        }
        public void ChkOutDate()
        {
            var Checkoutdate = chromeDriver.FindElement(By.XPath(LocatorClass.chkout_date));
            Checkoutdate.Clear();
            Checkoutdate.SendKeys(checkout_date);
        }
        public void AdultCount()
        {
            var adult_no = chromeDriver.FindElement(By.Id(LocatorClass.adultcount));
            var adult_no_dropdown = new SelectElement(adult_no);
            adult_no_dropdown.SelectByValue(adult_count);
        }
        public void ChildCount()
        {
            var child_no = chromeDriver.FindElement(By.Id(LocatorClass.childcount));
            var child_no_dropdown = new SelectElement(child_no);
            child_no_dropdown.SelectByValue(child_count);
        }
        public void Search()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.search)).Click();
        }
        public void Search_Validate()
        {
            string search_text = chromeDriver.FindElement(By.XPath(LocatorClass.search_validate)).Text;
            Assert.AreEqual(search_text,search_Validate);
        }

    }
}
