﻿using FinalProject.Support.CancelBooking;
using FinalProject.Support.Data;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Support.Logout
{
    public class LogoutClass: CancelBookingClass
    {

        string logout_text = DataClass.Logout_text;
        string login_again_text = DataClass.LoginAgain_text;

        
        public void Logout()
        {
            chromeDriver.FindElement(By.XPath(LocatorClass.Logout_btn)).Click();            
        }
        public void LogoutValidationText()
        {
            string logout_txt = chromeDriver.FindElement(By.ClassName(LocatorClass.Logout_txt)).Text;
            Assert.AreEqual(logout_txt, logout_text);
        }
        public void LoginAgain()
        {
            chromeDriver.FindElement(By.XPath(LocatorClass.Login_again_click)).Click();
        }
        public void LoginAgainValidationText()
        {
            string login_again_txt = chromeDriver.FindElement(By.ClassName(LocatorClass.Login_again_validate_text)).Text;
            Assert.AreEqual(login_again_txt, login_again_text);
        }       
    }
}
