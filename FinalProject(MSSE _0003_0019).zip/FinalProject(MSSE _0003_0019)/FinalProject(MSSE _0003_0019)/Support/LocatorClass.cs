﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Support
{
    public static class LocatorClass
    {
        public const string username = "username";
        public const string password = "password";
        public const string login_btn = "login";
        public const string loginvalidText = "welcome_menu";

        public const string invalidpassword = "invalidpassword";
        public const string invalidlogintext = "//b[contains(text(),'Invalid Login details or Your Password might have ')]";

        public const string Location = "location";
        public const string Hotels = "hotels";
        public const string Rm_Type = "room_type";
        public const string Rm_No = "room_nos";
        public const string chkin_date = "//input[@id='datepick_in']";
        public const string chkout_date = "//input[@id='datepick_out']";
        public const string adultcount = "adult_room";
        public const string childcount = "child_room";
        public const string search = "Submit";
        public const string search_validate = "//td[contains(text(),'Select Hotel')]";
        
        public const string search_invalid = "//span[@id='checkout_span']";

        public const string continue_btn = "continue";
        public const string sel_htlerror = "reg_error";
        public const string sel_ht_radio = "radiobutton_0";
        public const string bookhotel_validate = "//td[contains(text(),'Book A Hotel')]";

        public const string First_name = "first_name";
        public const string Last_name = "last_name";
        public const string bill_address = "address";
        public const string cc_no = "cc_num";
        public const string cc_type = "cc_type";
        public const string cc_exp_date = "cc_exp_month";
        public const string cc_exp_year= "cc_exp_year";
        public const string cc_cvv_no = "cc_cvv";
        public const string book_now = "book_now";
        public const string my_itinerary_btn = "my_itinerary";

        public const string bk_hotel_error = "cc_cvv_span";
       

        public const string bkd_itinerary_btn = "//a[contains(text(),'Booked Itinerary')]";
        public const string bkd_itinerary_txt = "login_title";
        public const string Search_order_Id = "order_id_text";
        public const string Go_btn = "search_hotel_id";
        public const string bkd_searcherror_txt = "search_result_error";

        public const string cancel_CheckBox = "table.content:nth-child(2) table.login table:nth-child(1) tbody:nth-child(1) tr:nth-child(2) td:nth-child(1) > input:nth-child(1)";
        public const string Cancel_selected_btn = "reg_button";
        public const string BookingCancelText = "search_result_error";

        public const string Logout_btn = "//a[contains(text(),'Logout')]";
        public const string Logout_txt = "reg_success";
        public const string Login_again_click = "//a[contains(text(),'Click here to login again')]";
        public const string Login_again_validate_text = "login_title";
                

    }
}
