﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Support.Data
{
    public static class DataClass
    {
        public static readonly string url;
        public static readonly string username;
        public static readonly string password;
        public static readonly string loginvalidText;

        public static readonly string invalidpassword;
        public static readonly string invalidlogintext;

        public static readonly string loc_Text;
        public static readonly string hotel_value;
        public static readonly string room_type;
        public static readonly string room_count;
        public static readonly string chkin_date;
        public static readonly string chkout_date;
        public static readonly string adult_count;
        public static readonly string child_count;
        public static readonly string searchvalidText;
        
        public static readonly string invalidchkout_date;
        public static readonly string invalidchkouttext;
       
        public static readonly string select_hotel_error;
        public static readonly string bookhotelvalidText;

        public static readonly string First_name;
        public static readonly string Last_name;
        public static readonly string bill_address;
        public static readonly string cc_no;
        public static readonly string cc_type;
        public static readonly string exp_month;
        public static readonly string exp_year;
        public static readonly string cvv_no;

        public static readonly string book_hotel_error;

        public static readonly string booked_itinerary_text;
        public static readonly string search_orderId;
        public static readonly string booked_searcherror_text;

        public static readonly string booking_cancel_text;

        public static readonly string Logout_text;
        public static readonly string LoginAgain_text;

        

        
        static DataClass()
        {
            JObject jsonData = JObject.Parse(File.ReadAllText(@"C:\Users\simra\source\repos\FinalProject  MSSE _0003_0019\FinalProject(MSSE _0003_0019)\FinalProject(MSSE _0003_0019)\Support\Data\Data.json"));

            url = jsonData["url"].ToString();
            username = jsonData["username"].ToString();
            password = jsonData["password"].ToString();
            loginvalidText = jsonData["LoginValidText"].ToString();

            invalidpassword = jsonData["invalidpassword"].ToString();
            invalidlogintext = jsonData["invalidlogintext"].ToString();

            loc_Text = jsonData["loc_Text"].ToString();
            hotel_value = jsonData["hotel_value"].ToString();
            room_type = jsonData["room_type"].ToString();
            room_count = jsonData["room_count"].ToString();
            chkin_date = jsonData["chkin_date"].ToString();
            chkout_date = jsonData["chkout_date"].ToString();
            adult_count = jsonData["adult_count"].ToString();
            child_count = jsonData["child_count"].ToString();
            searchvalidText = jsonData["searchvalidText"].ToString();

            invalidchkout_date = jsonData["invalidchkout_date"].ToString();
            invalidchkouttext = jsonData["invalidchkouttext"].ToString();

            select_hotel_error = jsonData["select_hotel_error"].ToString();
            bookhotelvalidText = jsonData["bookhotelvalidText"].ToString();

            First_name = jsonData["Firstname"].ToString();
            Last_name = jsonData["LastName"].ToString();
            bill_address = jsonData["Billing_add"].ToString();
            cc_no = jsonData["cc_no"].ToString();
            cc_type = jsonData["cc_type"].ToString();
            exp_month = jsonData["exp_month"].ToString();
            exp_year = jsonData["exp_year"].ToString();
            cvv_no = jsonData["cvv_no"].ToString();

            book_hotel_error = jsonData["book_hotel_error"].ToString(); 

            booked_itinerary_text = jsonData["booked_itinerary_text"].ToString();
            search_orderId = jsonData["search_orderId"].ToString();
            booked_searcherror_text = jsonData["booked_searcherror_text"].ToString();

            booking_cancel_text = jsonData["booking_cancel_text"].ToString();

            Logout_text = jsonData["Logout_text"].ToString();
            LoginAgain_text = jsonData["LoginAgain_text"].ToString();

        }
    }
}
