﻿using FinalProject.Support.Data;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Support.Login
{
    public class InvalidLogin : ValidLogin
    {     
        string invalidpassword = DataClass.invalidpassword;
        string expectedinvalidlogintext = DataClass.invalidlogintext;
       
        public void InvalidValidPassword()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.password)).SendKeys(invalidpassword);
        }
     
        public void InvalidLoginText()
        {
            string actualinvalidtext = chromeDriver.FindElement(By.XPath(LocatorClass.invalidlogintext)).Text;
            Assert.AreEqual(expectedinvalidlogintext, actualinvalidtext);
        }
    }
}
