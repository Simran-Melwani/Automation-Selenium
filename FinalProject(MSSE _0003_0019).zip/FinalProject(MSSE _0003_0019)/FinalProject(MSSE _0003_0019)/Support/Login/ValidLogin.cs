﻿using FinalProject.Support.Data;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace FinalProject.Support.Login
{
    public class ValidLogin:BaseClass
    {
        string username = DataClass.username;
        string password = DataClass.password;
        string loginvalidate = DataClass.loginvalidText;
        public void login_username()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.username)).SendKeys(username);
        }
        public void login_password()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.password)).SendKeys(password);
        }
        public void login()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.login_btn)).Click();
        }
        public void login_validate()
        {
            string logintext = chromeDriver.FindElement(By.ClassName(LocatorClass.loginvalidText)).Text;
            Assert.AreEqual(logintext, loginvalidate);
        }
    }
}
