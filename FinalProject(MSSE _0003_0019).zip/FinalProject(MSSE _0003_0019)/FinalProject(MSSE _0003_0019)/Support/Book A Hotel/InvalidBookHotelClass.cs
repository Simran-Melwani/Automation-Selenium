﻿using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FinalProject.Support.Select_Hotel;
using FinalProject.Support.Data;
using NUnit.Framework;

namespace FinalProject.Support.Book_A_Hotel
{
    public class InvalidBookHotelClass : ValidBookHotelClass
    {

        string book_error = DataClass.book_hotel_error;
        public void InvalidBookHotel()
        {
            string book_error_text = chromeDriver.FindElement(By.Id(LocatorClass.bk_hotel_error)).Text;
            Assert.AreEqual(book_error_text, book_error);
        }
    }
}

