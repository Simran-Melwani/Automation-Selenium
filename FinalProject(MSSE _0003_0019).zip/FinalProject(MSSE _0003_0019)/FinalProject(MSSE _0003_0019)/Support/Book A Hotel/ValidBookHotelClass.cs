﻿using FinalProject.Support.Data;
using FinalProject.Support.Select_Hotel;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Support.Book_A_Hotel
{
    public class ValidBookHotelClass: ValidSelectHotelClass
    {
        string First_name = DataClass.First_name;
        string Last_name = DataClass.Last_name;
        string Billing_add = DataClass.bill_address;
        string creditcard_no = DataClass.cc_no;
        string crdtcard_type = DataClass.cc_type;
        string cc_expiry_month = DataClass.exp_month;
        string cc_expiry_year = DataClass.exp_year;
        string cvv_no = DataClass.cvv_no;
        public void BH_FirstName()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.First_name)).SendKeys(First_name);
        }
        public void BH_LastName()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.Last_name)).SendKeys(Last_name);
        }
        public void Billing_Address()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.bill_address)).SendKeys(Billing_add);
        }
        public void Credit_Card_No()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.cc_no)).SendKeys(creditcard_no);
        }
        public void Credit_Card_Type()
        {
            var creditcard_type = chromeDriver.FindElement(By.Id(LocatorClass.cc_type));
            var creditcard_type_dropdown = new SelectElement(creditcard_type);
            creditcard_type_dropdown.SelectByValue(crdtcard_type);
        }
        public void Expiry_Month()
        {
            var expiry_month = chromeDriver.FindElement(By.Id(LocatorClass.cc_exp_date));
            var expiry_month_dropdown = new SelectElement(expiry_month);
            expiry_month_dropdown.SelectByValue(cc_expiry_month);

        }
        public void Expiry_Year()
        {
            var expiry_year = chromeDriver.FindElement(By.Id(LocatorClass.cc_exp_year));
            var expiry_year_dropdown = new SelectElement(expiry_year);
            expiry_year_dropdown.SelectByValue(cc_expiry_year);
        }
        public void CVV_Number()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.cc_cvv_no)).SendKeys(cvv_no);
        }
        public void Book_Now()
        {
            chromeDriver.FindElement(By.Id(LocatorClass.book_now)).Click();
        }
        public void My_Itinerary_Validate()
        {
            WebDriverWait wait = new WebDriverWait(chromeDriver, TimeSpan.FromSeconds(12));
            var button = wait.Until(driver =>
            {
                var element = driver.FindElement(By.Id(LocatorClass.my_itinerary_btn));
                { 
                    if (element.Displayed)
                    {
                       ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", element);
                       Thread.Sleep(2000);
                    }
                    return element.Displayed ? element : null;
                }
            });
            if (button != null)
            {
                Console.WriteLine("Button found and is displayed.");
            }
            else
            {
                Console.WriteLine("Button not found or is not displayed.");
            }




        }
    }
}
